﻿using CommandPattern.Core.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommandPattern.Core.Implementations
{
    public class CommandInterpreter : ICommandInterpreter
    {
        public string Read(string args)
        {
            var commandArgs = args.Trim().Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();

            if (commandArgs[0] == "Hello")
            {
                var method = typeof(HelloCommand).GetMethod("Execute");
                return method.Invoke(Activator.CreateInstance(typeof(HelloCommand)), new object[] { new string[] { commandArgs[1] } }).ToString();
            }
            else
            {
                var method = typeof(ExitCommand).GetMethod("Execute");
                return method.Invoke(Activator.CreateInstance(typeof(ExitCommand)), new object[] { commandArgs })?.ToString();
            }
        }
    }
}
