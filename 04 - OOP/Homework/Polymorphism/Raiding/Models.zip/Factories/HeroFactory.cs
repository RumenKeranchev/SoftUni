﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public abstract class HeroFactory
    {
        public abstract BaseHero CreateHero();
    }
}
