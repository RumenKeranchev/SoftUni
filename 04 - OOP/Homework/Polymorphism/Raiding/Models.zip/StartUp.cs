﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Raiding
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var heroes = new List<BaseHero>();
            HeroFactory heroFactory = null;

            while (n > heroes.Count)
            {
                try
                {
                    var name = Console.ReadLine();
                    var type = Console.ReadLine().Trim().ToLowerInvariant();

                    heroFactory = type switch
                    {
                        "druid" => new DruidFactory(name),
                        "paladin" => new PaladinFactory(name),
                        "rogue" => new RogueFactory(name),
                        "warrior" => new WarriorFactory(name),
                        _ => throw new Exception("Invalid Hero!"),
                    };

                    heroes.Add(heroFactory.CreateHero());
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            var bossPower = long.Parse(Console.ReadLine());

            foreach (var hero in heroes)
            {
                Console.WriteLine(hero.CastAbility());
            }

            var totalPower = heroes.Select(h => (long)h.Power).DefaultIfEmpty().Sum();
            Console.WriteLine(totalPower >= bossPower ? "Victory!" : "Defeat...");
        }
    }
}
